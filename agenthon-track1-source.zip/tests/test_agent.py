# SPDX-License-Identifier: MIT
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
AGENT = ROOT / 'agent/solve.py'
if not AGENT.exists():
    AGENT = ROOT / 'solve.py'  # The built image flattens agent/ under /agent.
spec = importlib.util.spec_from_file_location('solver', AGENT)
solver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(solver)


class FakeHouse:
    replies = []
    recorded = []
    def __init__(self, deadline):
        self.calls = 0
    def ask(self, messages, max_tokens=4000):
        self.calls += 1
        self.recorded.append(messages)
        return self.replies.pop(0)


def program(value):
    return "```python\nimport os,json\nfrom pathlib import Path\nPath(os.environ['OUT_DIR'],'answer.json').write_text(json.dumps({'value':" + str(value) + "}))\n```"


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=os.environ.get('DELTANLP_TEST_ROOT', ROOT))
        self.base = Path(self.tmp.name)
        self.old_tempdir = tempfile.tempdir
        tempfile.tempdir = str(self.base)
        self.task = self.base / 'input'
        self.out = self.base / 'output'
        (self.task / 'checks').mkdir(parents=True)
        (self.task / 'environment/data').mkdir(parents=True)
        (self.task / 'instruction.md').write_text('Compute the square of the input value and write answer.json.\nCANARY: abcdefab-1234-1234-1234-abcdefabcdef')
        (self.task / 'card.toml').write_text('[agent]\ntimeout_sec=1800\n')
        (self.task / 'environment/data/input.json').write_text('{"value": 3}')
        (self.task / 'checks/test_outputs.py').write_text('import json,os\nfrom pathlib import Path\ndef test_value():\n assert json.loads(Path(os.environ["OUTPUT_DIR"],"answer.json").read_text())["value"] == 9\n')
        FakeHouse.recorded = []
    def tearDown(self):
        tempfile.tempdir = self.old_tempdir
        self.tmp.cleanup()
    def test_repairs_failed_test(self):
        FakeHouse.replies = ['Square the input, output a JSON number.', program(8), program(9)]
        result = solver.solve(self.task, self.out, FakeHouse, budget=60)
        self.assertEqual(result['preview_best'], 1)
        self.assertEqual(result['house_requests'], 3)
        self.assertEqual(json.loads((self.out/'answer.json').read_text())['value'], 9)
        self.assertIn('AssertionError', FakeHouse.recorded[-1][-1]['content'])
        self.assertEqual([p.name for p in self.out.iterdir()], ['answer.json'])
    def test_rejects_syntax_and_recovers(self):
        FakeHouse.replies = ['Square the input.', '```python\ndef broken(\n```', program(9)]
        result = solver.solve(self.task, self.out, FakeHouse, budget=60)
        self.assertEqual(result['preview_best'], 1)
    def test_redacts_credentials_and_canary(self):
        os.environ['MODEL_TOKEN'] = 'synthetic-private-token'
        try:
            self.assertNotIn('synthetic-private-token', solver.redact('synthetic-private-token'))
            self.assertNotIn('abcdefab-1234', solver.task_context(self.task))
            env = solver.child_environment(self.task,self.out,self.base)
            self.assertNotIn('MODEL_TOKEN',env)
        finally:
            os.environ.pop('MODEL_TOKEN')
    def test_missing_tests_never_claims_pass(self):
        score, _ = solver.check_candidate(None,self.out,self.base,os.environ.copy(),5)
        self.assertLess(score,0)
    def test_process_timeout(self):
        status, _ = solver.run_process([sys.executable,'-c','import time; time.sleep(10)'],os.environ.copy(),self.base,1)
        self.assertEqual(status,124)
    def test_canary_output_rejected(self):
        self.out.mkdir()
        (self.out/'answer.json').write_text('{"debug":"abcdefab-1234-1234-1234-abcdefabcdef"}')
        with self.assertRaises(ValueError):
            solver.check_output_tree(self.out,['abcdefab-1234-1234-1234-abcdefabcdef'])
    def test_reward_forgery_rejected(self):
        self.out.mkdir()
        (self.out/'reward.json').write_text('{"reward":1}')
        with self.assertRaises(ValueError):
            solver.check_output_tree(self.out,[])
    def test_stale_report_removed(self):
        checks = self.base/'emptychecks'
        checks.mkdir()
        (self.base/'preview-report.json').write_text('{"summary":{"passed":1,"total":1}}')
        score, _ = solver.check_candidate(checks,self.out,self.base,os.environ.copy(),10)
        self.assertNotEqual(score,1)
    def test_restores_best_partial_candidate(self):
        (self.task/'checks/test_outputs.py').write_text('import json,os\nfrom pathlib import Path\ndef value():\n return json.loads(Path(os.environ["OUTPUT_DIR"],"answer.json").read_text())["value"]\ndef test_positive():\n assert value() > 0\ndef test_exact():\n assert value() == 9\n')
        FakeHouse.replies = ['Square the input.', program(8)] + [program(-1)] * 7
        result = solver.solve(self.task,self.out,FakeHouse,budget=60)
        self.assertEqual(result['preview_best'],0.5)
        self.assertEqual(json.loads((self.out/'answer.json').read_text())['value'],8)
    def test_zip_schema_lists_names_without_reading_payload(self):
        archive = self.task/'environment/data/prices.zip'
        with zipfile.ZipFile(archive,'w') as z:
            z.writestr('prices.csv','secret-payload')
        context = solver.task_context(self.task)
        self.assertIn('prices.csv',context)
        self.assertNotIn('secret-payload',context)
    def test_house_request_contract_and_truncation(self):
        class Reply:
            def __enter__(self): return self
            def __exit__(self,*args): pass
            def read(self,limit):
                return b'{"choices":[{"finish_reason":"length","message":{"content":"partial"}}]}'
        with patch.dict(os.environ,{'MODEL_ENDPOINT':'http://house.invalid',
             'MODEL_NAME':'injected-house','MODEL_TOKEN':'synthetic-token','QFBENCH_SEED':'726'}):
            with patch.object(solver.urllib.request,'urlopen',return_value=Reply()) as mocked:
                house = solver.House(time.monotonic()+120)
                with self.assertRaises(ValueError):
                    house.ask([{'role':'user','content':'synthetic task'}],9999)
                request = mocked.call_args.args[0]
                body = json.loads(request.data)
                self.assertEqual(request.full_url,'http://house.invalid/v1/chat/completions')
                self.assertEqual(body['max_tokens'],4000)
                self.assertEqual(body['model'],'injected-house')
                self.assertEqual(house.calls,1)
    @unittest.skipUnless(importlib.util.find_spec('openpyxl'), 'Requires image dependency openpyxl')
    def test_spreadsheet_schema(self):
        import openpyxl
        path = self.task/'environment/data/table.xlsx'
        book = openpyxl.Workbook()
        book.active.append(['date','price'])
        book.active.append(['2026-01-01',123])
        book.save(path)
        book.close()
        schema = solver.binary_schema(path)
        self.assertIn('price',schema)
        self.assertIn('"rows": 2',schema)
    @unittest.skipUnless(importlib.util.find_spec('pyarrow'), 'Requires image dependency pyarrow')
    def test_parquet_schema(self):
        import pyarrow as pa
        import pyarrow.parquet as pq
        path = self.task/'environment/data/table.parquet'
        pq.write_table(pa.table({'price':[1.,2.,3.]}),path)
        schema = solver.binary_schema(path)
        self.assertIn('rows=3',schema)
        self.assertIn('price: double',schema)


if __name__ == '__main__':
    unittest.main()
