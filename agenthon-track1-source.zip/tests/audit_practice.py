# SPDX-License-Identifier: MIT
"""Inspect public unit interfaces without solving, copying, or editing their data."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('solver', ROOT/'agent/solve.py')
solver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(solver)
kit = Path(sys.argv[1])
units = sorted((kit/'units').iterdir())
categories = Counter()
formats = Counter()
contexts = []
for unit in units:
    if not unit.is_dir():
        continue
    tracked = list(unit.rglob('*.py')) + list(unit.rglob('*.toml')) + list(unit.rglob('*.md'))
    before = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked}
    card = tomllib.loads((unit/'card.toml').read_text())
    categories[card['metadata']['category']] += 1
    for p in (unit/'environment/data').rglob('*'):
        if p.is_file():
            formats[p.suffix] += 1
    context = solver.task_context(unit)
    assert '[canary line removed]' in context or 'canary' not in context.lower()
    assert 'instruction.md:' in context and 'card.toml:' in context
    assert before == {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked}
    contexts.append(len(context))
result = {'units_inspected':len(contexts),'categories':dict(categories),'data_extensions':dict(formats),
          'context_characters_max':max(contexts),'input_sources_unchanged':True,
          'claimed_solve_rate':None,'house_execution_tested':False}
(ROOT/'practice-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
